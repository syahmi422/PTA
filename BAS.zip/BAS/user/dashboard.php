<?php
session_start();
include('../include/config.php');
// include('../include/session_user.php');

if(isset($_SESSION['id'])){
  $id=$_SESSION['id'];
  $query=mysqli_query($con,"SELECT * FROM pelajar WHERE id_std='$id'");
  $fetch=mysqli_fetch_array($query);
}
// $query=mysqli_query($con,"SELECT * FROM pelajar WHERE id_std='$id'");
// $fetch=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>TicketEase KVKS</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.0/dist/sweetalert2.min.css">
</head>

<style>
	body{
		font-family: quicksand;
	}
  :root{
    scroll-behavior: smooth;
  }
</style>

<body class="bg-light">
  <?php include('../include/nav_user.php');?>
  <!-- home -->
  <img src="../image/background.jpg" id="home" class="img img-fluid h-50">
  <div class="container-fluid p-4" style="background-color: #dcdcdc;">
    <div class="row">
      <div class="col-12 col-md m-2 text-center">
        <i class='bx bx-bus rounded-circle p-4 text-white' style="font-size: 700%; background-color: #4e5180;"></i><br><br>
        <h4>Bas</h4>
      </div>
      <div class="col-12 col-md m-2 text-center">
        <i class='bx bx-check-shield rounded-circle p-4 text-white' style="font-size: 700%; background-color: #4e5180;"></i><br><br>
        <h4>Keselamatan Terjamin</h4>
      </div>
      <div class="col-12 col-md m-2 text-center">
        <i class='bx bxs-offer rounded-circle p-4 text-white' style="font-size: 700%; background-color: #4e5180;"></i><br><br>
        <h4>Murah</h4>
      </div>
      <div class="col-12 col-md m-2 text-center">
        <i class='bx bx-support rounded-circle p-4 text-white' style="font-size: 700%; background-color: #4e5180;"></i><br><br>
        <h4>Sokongan Pantas</h4>
      </div>
    </div>
  </div>

  <!-- about -->
  <div class="container-fluid bg-white p-4" id="about">
    <p class="fs-1 text-center fw-bold" style="color: #4e5180;">TENTANG KAMI</p>
    <div class="row">
      <div class="col-12 col-md m-2 ">
        <center><span class="fs-2 fw-bold">Selamat Datang Ke TicketEase</span></center>
        <p class="fs-5 mt-3" style="text-align: justify;">Kami dengan bangga memperkenalkan sistem bas yang telah dibangunkan oleh pasukan kami. Sistem ini merupakan hasil daripada usaha
         berterusan kami untuk memberikan pengalaman pengangkutan awam yang lebih baik kepada masyarakat. Sistem bas kami direka dengan menggunakan teknologi terkini dan terbaik untuk 
         memastikan kebolehpercayaan, keselesaan dan efisien dalam perjalan harian. Kami berkomitmen untuk terus meningkatkan sistem bas kami dengan mengambil kira maklum balas pengguna dan memanfaatkan kemajuan teknologi terkini.</p>
          
      </div>
      <div class="col-12 col-md m-2 text-center">
        <img src="../image/gmbr.jpeg" alt="" class="img img-fluid rounded-2" style="filter: brightness(60%);">
      </div>
    </div>
  </div>
  
  <!-- contact us -->
  <div class="container-fluid p-4" id="contact" style="background-color: #dcdcdc;">
    <p class="fs-1 text-center fw-bold" style="color: #4e5180;">HUBUNGI KAMI</p>
    <div class="row justify-content-center">
      <?php
        $query=mysqli_query($con,"SELECT * FROM admin WHERE role='1'");
        while($fetch1=mysqli_fetch_array($query)){
      ?>
      <div class="card shadow-sm m-3" style="width: 25rem;">
        <div class="card-body">
          <p class="card-title">
            <p class="text-center"><i class='bx bxs-user-circle' style='color:#7d7d7d; font-size: 500%;'></i></p>
            
            <p class="text-center"><?=$fetch1['nama']?></p>
            
            <p class="text-center"><?=$fetch1['notel']?></p>
          </p>
        </div>
      </div>
      <?php
        }
      ?>
    </div>
    <hr>
    <p class="fs-4">Hantar Mesej Kepada Kami</p>
    <center>
      <form method="POST" action="contact.php" class="col-12 col-md-6">
        <div class="mb-3 row-sm-6">
          <input type="text" name="nama" class="form-control p-3" placeholder="Nama" required>
        </div>
        <div class="mb-3 row-sm-6">
          <input type="email" name="emel" class="form-control p-3" placeholder="E-mel" required>
        </div>
        <div class="mb-3 row-sm-6">
          <input type="text" name="subjek" class="form-control p-3" placeholder="Subjek" required>
        </div>
        <div class="mb-3 row-sm-6">
          <textarea class="form-control p-3" placeholder="Mesej" name="mesej" rows="10" required></textarea>
        </div>
        <button type="submit" name="hantar" class="btn w-100 rounded-1 text-light p-2" style="background-color: #4e5180;" onmouseover="this.style.backgroundColor='#3b3d61'" onmouseout="this.style.backgroundColor='#4e5180'">Hantar</button>
      </form>
    </center>
    
  </div>
  <?php 
  include('../include/footer.php');
  ?>

</body>



<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script> -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- <script>
  const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
  const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))
</script> -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    <?php if (isset($_SESSION['title']) && $_SESSION['title'] != '') { ?>
        Swal.fire({
            confirmButtonColor: '#5453a6',
            title: '<?php echo $_SESSION['title']; ?>',
            text: '<?php echo $_SESSION['text']; ?>',
            icon: '<?php echo $_SESSION['icon']; ?>'
        });
    <?php }
    unset($_SESSION['title']); ?>
</script>
</html>