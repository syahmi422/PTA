<?php
include('../include/config.php');
include('../include/session_user.php');

$query=mysqli_query($con,"SELECT * FROM pelajar WHERE emel='$emel'");
$fetch=mysqli_fetch_array($query);

if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $emel=$_POST['emel'];
    $nokp=$_POST['nokp'];
    $method=$_POST['method'];

    if($method == "cash"){
        $status='0';
        $tiket='0';
    }if($method == 'tng'){
        $status='1';
        $tiket='1';
    }

    $query=mysqli_query($con,"INSERT INTO `tiket`(`nama`, `no_kp`, `bil_tiket`, `method`, `status`) VALUES ('$name','$nokp','$tiket','$method','$status')");

    header('Location: dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TicketEase KVKS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
</head>
<style>
    body{
        font-family: quicksand;
        background-color: #d2b48c;
    }
    <style>
        /* Add some CSS for aesthetics */
        #imageContainer {
            text-align: center;
            margin-top: 20px;
        }

        img {
            max-width: 30%;
            height: auto;
        }
    </style>
</style>
<body>
    <div class="container bg-light mt-3 mb-3 p-3 rounded-4">
        <div class="fs-4 text-center fw-bold">
            <img src="../image/logo.png" class="w-25">
            <br>
            <button class="btn btn-primary mb-3" onclick="window.location='dashboard.php'">Kembali</button>
            <br>
            Borang Pembelian Tiket
        </div>
        <br>
        <div class="text-light p-3" style="background-color: #846234;">
            <strong>TERMA & SYARAT PERKHIDMATAN BAS TRANSIT</strong>
            <ol>
                <li>Pelajar yang ingin menggunakan perkhidmatan bas transit perlu membayar sebanyak RM15.00 per tiket.</li>
                <li>Perkhidmatan ini merupakan inisiatif Majlis Perwakilan Pelajar (MPP) KV Kuala Selangor atas permintaan pelajar. Perkhidmatan ini diuruskan oleh pihak MPP (Bukan pihak pengurusan Kolej atau Kolej Kediaman).</li>
                <li>Sekiranya perkhidmatan bas ini mendapat sambutan yang <strong>kurang memuaskan</strong>, perkhidmatan bas ini akan <strong>digantung.</strong></li>
                <li>Sila maklumkan kepada <strong>ibu bapa / penjaga</strong> sekiranya anda memilih mod pengangkutan ini bagi mengelakkan kekeliruan dan salah faham.</li>
                <li>MPP <strong>tidak akan bertanggungjawab</strong> atau kecuaian dan kelalaian pelajar sekiranya berlaku perkara yang tidak diingini di luar kawasan kolej.</li>
                <li>Sebarang pembatalan tiket adalah <strong>tidak dibenarkan</strong> dan duit <strong>tidak</strong> akan dipulangkan.</li>
                <li>Setiap pelajar hanya dibenarkan untuk membeli <strong>satu tiket sahaja</strong>.</li>
            </ol>
        </div>

        <form method="POST">
            <div class="container mt-3">
                <label class="form-label">Nama Pelajar</label>
                <input class="form-control" name="name" type="text" value="<?php echo $fetch['nama']?>" readonly>
            </div>

            <div class="container mt-3">
                <label class="form-label">E-mel</label>
                <input class="form-control" name="emel" type="text" value="<?php echo $fetch['emel']?>" readonly>
            </div>

            <div class="container mt-3">
                <input class="form-control" name="nokp" type="hidden" value="<?php echo $fetch['no_kp']?>" readonly>
            </div>

            <div class="container mt-3">
                <label class="form-label">Kaedah Pembayaran</label>
                <br>
                <input type="radio" class="form-check-input" name="method" value="cash">
                Tunai
                <br>
                <input type="radio" class="form-check-input" name="method" id="../image/qrcode.jpeg" value="tng">
                Touch 'n Go
            </div>
            <div id="imageContainer">
                <img id="displayedImage">
            </div>

            <div class="container">
                <input type="submit" class="btn btn-success w-100" name="submit" value="Hantar">
            </div>
        </form>
    </div>

    
    <script>
        function changeImage() {    
            const radioButtons = document.querySelectorAll('input[name="method"]');
            const displayedImage = document.getElementById('displayedImage');

            for (const radioButton of radioButtons) {
                radioButton.addEventListener('change', function () {
                    if (this.checked) {
                        const selectedImage = this.id;
                        displayedImage.src = selectedImage;
                    }
                });
            }
        }

        changeImage();
    </script>

</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

</html>