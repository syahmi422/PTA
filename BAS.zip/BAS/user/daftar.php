<?php
include('../include/config.php');


if(isset($_POST['hantar'])){
  $nama=$_POST['nama'];
  $nokp=$_POST['nokp'];
  $program=$_POST['program'];
  $emel=$_POST['emel'];
  $no_tel=$_POST['no_tel'];

  $nama_bapa=$_POST['nama_bapa'];
  $notel_bapa=$_POST['notel_bapa'];
  $nama_ibu=$_POST['nama_ibu'];
  $notel_ibu=$_POST['notel_ibu'];

  $check=mysqli_query($con,"SELECT * FROM pelajar WHERE no_kp='$nokp'");

  if(mysqli_num_rows($check)>0){
    $_SESSION['title']='Gagal';
    $_SESSION['icon']='error';
    $_SESSION['text']='Akaun sudah berdaftar.';
    $_SESSION['location']='login.php';
  }else{
    $query=mysqli_query($con,"INSERT INTO pelajar(nama_std, no_kp, no_tel, emel, id_program, nama_bapa, notel_bapa, nama_ibu, notel_ibu) VALUES (UPPER('$nama'),'$nokp','$no_tel','$emel','$program',UPPER('$nama_bapa'),'$notel_bapa',UPPER('$nama_ibu'),'$notel_ibu')");

    if ($query) {
      $_SESSION['title']='Berjaya';
      $_SESSION['icon']='success';
      $_SESSION['text']='Pendaftaran Berjaya!';
      $_SESSION['location']='login.php';
    }else{
      $_SESSION['title']='Gagal';
      $_SESSION['icon']='error';
      $_SESSION['text']='Pendaftaran Gagal. Sila cuba sebentar lagi.';
      $_SESSION['location']='daftar.php';
    }
  }
}
?>
<!DOCTYPE html> 
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TicketEase KVKS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.0/dist/sweetalert2.min.css">
</head>
<style>
body{
    font-family: quicksand;
    background-color: #5453a6;
}
#step2{
  display: none;
}
</style>
<body>

<form method="POST" id="regForm">
<div class="container bg-light p-3 shadow rounded-3 position-absolute top-50 start-50 translate-middle">

    <center>
			<p class="fs-3">TicketEase KVKS</p>
      <p class="fw-bold fs-4">Daftar Pengguna</p>
			<input type="button" class="btn btn-primary" value="Kembali" onclick="window.location='login.php'">
		</center>


    <div class="step" id="step1"> 
        <hr class="border border-secondary border-1">
        <span class="fs-6 fw-bold text-secondary"><center>BAHAGIAN A: MAKLUMAT PELAJAR</center></span>
        <hr class="border border-secondary border-1">
        <br>

        <div class="row mb-3 ">
          <label class="col-sm-2 col-form-label">Nama Penuh</label>
          <div class="col-sm-10">
            <input type="text" name="nama" class="form-control" placeholder="Masukkan Nama Penuh Anda" required>
          </div>
        </div>

        <div class="row mb-3 ">
          <label class="col-sm-2 col-form-label">No. Kad Pengenalan</label>
          <div class="col-sm-10">
            <input type="text" name="nokp" class="form-control" placeholder="Masukkan No. Kad Pengenalan (tanpa -)" required>
          </div>
		    </div>

		    <div class="row mb-3 ">
          <label class="col-sm-2 col-form-label">Program</label>
          <div class="col-sm-10">
            <select name="program" class="form-select" required>
              <option selected disabled value="">Sila Pilih</option>

              <?php
              $query=mysqli_query($con,"SELECT * FROM program");
              while($fetch=mysqli_fetch_array($query)){
              ?>

              <option value="<?=$fetch['id_program'];?>"><?=$fetch['nama'];?> - <?=$fetch['tahun'];?></option>
              
              <?php
              }
              ?>

            </select>
          </div>
        </div>

        <div class="row mb-3 ">
          <label class="col-sm-2 col-form-label">E-mel</label>
          <div class="col-sm-10">
            <input type="email" name="emel" class="form-control" placeholder="Masukkan E-mel Anda" required>
          </div>
        </div>

        <div class="row mb-3 ">
          <label class="col-sm-2 col-form-label">No. Telefon</label>
          <div class="col-sm-10">
            <input type="text" name="no_tel" class="form-control" placeholder="Masukkan No. Telefon (tanpa -)" required>
          </div>
        </div>

        <div class="row mt-5 mb-3">
          <div class="col">
          <button type="submit" class="btn btn-primary w-100"  onclick="nextStep(1)">Seterusnya</button>
          </div>
        </div>
    </div>

    <div class="step" id="step2">
        <hr class="border border-secondary border-1">
        <span class="fs-6 fw-bold text-secondary"><center>BAHAGIAN B: MAKLUMAT IBU BAPA</center></span>
        <hr class="border border-secondary border-1">
        <br>
        
        <div class="row mb-3">
			    <label class="col-sm-2 col-form-label">Nama Penuh Bapa</label>
			    <div class="col-sm-10">
				    <input type="text" name="nama_bapa" class="form-control" placeholder="Masukkan Nama Penuh Bapa Anda" required>
			    </div>
        </div> 

        <div class="row mb-3">
			    <label class="col-sm-2 col-form-label">No. Telefon Bapa</label>
			    <div class="col-sm-10">
				    <input type="text" name="notel_bapa" class="form-control" placeholder="Masukkan No. Telefon (tanpa -)" required>
			    </div>
		    </div>

        <hr>

        <div class="row mb-3 ">
			    <label class="col-sm-2 col-form-label">Nama Penuh Ibu</label>
			    <div class="col-sm-10">
				    <input type="text" name="nama_ibu" class="form-control" placeholder="Masukkan Nama Penuh Ibu Anda" required>
			    </div>
        </div>

        <div class="row mb-3 ">
			    <label class="col-sm-2 col-form-label">No. Telefon Ibu</label>
			    <div class="col-sm-10">
				    <input type="text" name="notel_ibu" class="form-control" placeholder="Masukkan No. Telefon (tanpa -)" required>
			    </div>
		    </div>

        <div class="row mt-5 mb-3">
          <div class="col col-md">
            <button type="button" class="btn btn-primary w-100" onclick="prevStep(2)">Sebelumnya</button>
            
          </div>
          <div class="col col-md">
          <button type="submit" name="hantar" class="btn btn-success w-100">Hantar</button>
          </div>
        </div>
    </div>

</form>

</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    <?php if (isset($_SESSION['title']) && $_SESSION['title'] != '') { ?>
        Swal.fire({
            confirmButtonColor: '#5453a6',
            title: '<?=$_SESSION['title']; ?>',
            text: '<?=$_SESSION['text']; ?>',
            icon: '<?=$_SESSION['icon']; ?>'
        }).then((result) => {
        if (result.isConfirmed) {
          window.location.href='<?=$_SESSION['location']?>';
        }
      });
    <?php }
    unset($_SESSION['title']); ?>
</script>
<script>
    function nextStep(currentStep) {
       
        if (currentStep === 1) {
            var nama = document.getElementsByName('nama')[0].value;
            var nokp = document.getElementsByName('nokp')[0].value;
            var program = document.getElementsByName('program')[0].value;
            var emel = document.getElementsByName('emel')[0].value;
            var no_tel = document.getElementsByName('no_tel')[0].value;

            
            if (nama === '' || nokp === '' || program === '' || emel === '' || no_tel === '') {
                return;
            }
        }

        document.getElementById('step' + currentStep).style.display = 'none';
        document.getElementById('step' + (currentStep + 1)).style.display = 'block';
    }

    function prevStep(currentStep) {
        document.getElementById('step' + currentStep).style.display = 'none';
        document.getElementById('step' + (currentStep - 1)).style.display = 'block';
    }
</script>
</html>

