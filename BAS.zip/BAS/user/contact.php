<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 
require '../PHPMailer-master/src/Exception.php';
require '../PHPMailer-master/src/PHPMailer.php';
require '../PHPMailer-master/src/SMTP.php';
 
if(isset($_POST['hantar'])){
    
    $mail = new PHPMailer(true);
    
    $mail->isSMTP();
    $mail->SMTPDebug = 0;
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'muhammadsyahmi422@gmail.com';
    $mail->Password = 'jhes rclp ftzq erxj';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    // $mail->SMTPDebug = 2;
        
    $mail->setFrom($_POST['emel'], strtoupper($_POST['nama'])); 
    
    $mail->addAddress('muhammadsyahmi422@gmail.com');
        
    
    $mail->isHTML(true);
    
    $mail->Subject = $_POST['subjek'];
    $mail->Body =  $_POST['mesej'];
    
    if ($mail->send()) {
    
        // echo"success";
        // header('Location: dashboard.php');
        $_SESSION['title']='Berjaya';
        $_SESSION['icon']='success';
        $_SESSION['text']='Terima kasih kerana menghantar kami mesej';
        header('Location: dashboard.php');
        exit();
    
    } else {
        // echo "error";
        $_SESSION['title']='Gagal';
        $_SESSION['icon']='error';
        $_SESSION['text']='Penghantaran mesej tidak berjaya. Sila cuba sebentar lagi';
        header('Location: dashboard.php');
        exit();
    }
}
?>