<?php
include('../include/config.php');
include('../include/session_user.php');

$query=mysqli_query($con,"SELECT * FROM pelajar WHERE id_std='$id'");
$fetch=mysqli_fetch_array($query);

// count ticket 
// $query2=mysqli_query($con,"SELECT COUNT(no_kp) AS bil_tiket FROM tiket");
// $fetch2=mysqli_fetch_array($query2);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>TicketEase KVKS</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
</head>

<style>
	body{
		font-family: quicksand;
	}
    :root{
        scroll-behavior: smooth;
    }
</style>

<body class="bg-light">
	<?php include('../include/nav_user.php');?>
    <div class="container-fluid p-5" style="background-color: #4e5180;">
		<div class="container bg-light rounded-1 shadow p-3 table-responsive">
			<div class="bg-dark text-light p-3 overflow-x-scroll">KV Kuala Selangor > MRT Sungai Buloh</div>
			<br>
			<table class="table">
				<thead>
					<tr>
						<th>BAS / VAN</th>
						<th>TIKET</th>
						<th></th>
					</tr>
				</thead>
				<?php
                $query=mysqli_query($con,"SELECT * FROM kenderaan");
                while($data=mysqli_fetch_array($query)){

                    $query1=mysqli_query($con, "SELECT COUNT(bil_tiket) AS bil_tiket FROM tiket WHERE id_vehicle =".$data['id_vehicle']);
                    $fetch1=mysqli_fetch_array($query1);
                ?>
				<tbody>
					<tr>
						<td><?=$data['type'];?></td>
						<td><?=$fetch1['bil_tiket'];?>/<?=$data['seat'];?></td>
						<td class="text-center">
							<button class="btn btn-success w-100 h-50" onclick="window.location='beli.php?id=<?=$data['id_vehicle'];?>'" id="btn<?=$data['id_vehicle']?>">BELI</button>
						</td>
					</tr>
				</tbody>
                <?php
				echo"
				<script>
				if(".$fetch1['bil_tiket'].">=".$data['seat']."){
					document.getElementById('btn".$data['id_vehicle']."').disabled = true;
					document.getElementById('btn".$data['id_vehicle']."').textContent = 'TERJUAL';
					document.getElementById('btn".$data['id_vehicle']."').style.backgroundColor = '#dc3545';
					document.getElementById('btn".$data['id_vehicle']."').style.border = '0';
				} else {
					document.getElementById('btn".$data['id_vehicle']."').disabled = false;
				}
				</script>
				";
                }
                ?>
			</table>
		</div>
	</div>
	<div class="container-fluid p-4 bg-white">
		<p class="fs-1 text-center fw-bold" style="color: #4e5180;">TERMA & SYARAT</p>
		<ol>
            <li><p>Pelajar yang ingin menggunakan perkhidmatan bas transit perlu membayar sebanyak RM15.00 per tiket.</p></li>
            <li><p>Perkhidmatan ini merupakan inisiatif Majlis Perwakilan Pelajar (MPP) KV Kuala Selangor atas permintaan pelajar. Perkhidmatan ini diuruskan oleh pihak MPP (Bukan pihak pengurusan Kolej atau Kolej Kediaman).</p></li>
            <li><p>Sekiranya perkhidmatan bas ini mendapat sambutan yang <strong>kurang memuaskan</strong>, perkhidmatan bas ini akan <strong>dibatalkan.</strong></p></li>
            <li><p>Sila maklumkan kepada <strong>ibu bapa / penjaga</strong> sekiranya anda memilih mod pengangkutan ini bagi mengelakkan kekeliruan dan salah faham.</p></li>
            <li><p>MPP <strong>tidak akan bertanggungjawab</strong> atau kecuaian dan kelalaian pelajar sekiranya berlaku perkara yang tidak diingini di luar kawasan kolej.</p></li>
            <li><p>Sebarang pembatalan tiket adalah <strong>tidak dibenarkan</strong> dan duit <strong>tidak</strong> akan dipulangkan.</p></li>
            <li><p>Setiap pelajar hanya dibenarkan untuk membeli <strong>satu tiket sahaja</strong>.</p></li>
        </ol>
	</div>
	<?php include('../include/footer.php');?>
</body>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
    const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))
</script>
</html>