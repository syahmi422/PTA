<?php
include('../include/config.php');
include('../include/session_user.php');

$query=mysqli_query($con,"SELECT * FROM pelajar WHERE id_std='$id'");
$fetch=mysqli_fetch_array($query);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>TicketEase KVKS</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
</head>

<style>
	body{
		font-family: quicksand;
	}
    :root{
        scroll-behavior: smooth;
    }
</style>

<body class="bg-light">
	<?php include('../include/nav_user.php');?>
    <div class="container-fluid bg-white p-4">
        <p class="fs-1 text-center fw-bold" style="color: #4e5180;">SEMAKAN TIKET</p>
        <?php
        $query=mysqli_query($con,"SELECT * FROM pelajar JOIN tiket ON pelajar.id_std = tiket.id_std JOIN program ON pelajar.id_program = program.id_program WHERE pelajar.id_std='$id'");
        $fetch=mysqli_fetch_array($query);
        if($fetch){
        ?>
        <div class="col-lg-4 bg-light p-4 shadow">
            <?php
            if($fetch['status']==0){
                echo"<strong class=\"fs-1 text-warning\">BELUM SELESAI</strong>";
            }else if($fetch['status']==1){
                echo"<strong class=\"fs-1 text-success\">SELESAI</strong>";
            }else if($fetch['status']==2){
                echo"<strong class=\"fs-1 text-danger\">DIBATALKAN</strong>";
            }
            ?>
            <br>
            <strong class="fs-4 text-secondary">Status Pembelian</strong>
        </div>
        <br>
        <table class="table">
            <tr>
                <th>ID Bas</th>
                <th>:</th>
                <td><?=$fetch['id_vehicle'];?></td>
            </tr>
            <tr>
                <th>Nama Pembeli</th>
                <th>:</th>
                <td><?=$fetch['nama_std'];?></td>
            </tr>
            <tr>
                <th>No. KP</th>
                <th>:</th>
                <td><?=$fetch['no_kp'];?></td>
            </tr>
            <tr>
                <th>Program</th>
                <th>:</th>
                <td><?=$fetch['program'];?></td>
            </tr>
            <tr>
                <th>No. Tel</th>
                <th>:</th>
                <td><?=$fetch['no_tel'];?></td>
            </tr>
            <tr>
                <th>Lokasi</th>
                <th>:</th>
                <td>Kolej Vokasional Kuala Selangor > MRT Sungai Buloh</td>
            </tr>
            <tr>
                <th>Status</th>
                <th>:</th>
                <td>
                    <?php
                    if($fetch['status']==0){
                        echo"<span class=\"text-light pt-1 pb-1 ps-3 pe-3 rounded-pill bg-warning\">BELUM SELESAI</strong>";
                    }else if($fetch['status']==1){
                        echo"<span class=\"text-light pt-1 pb-1 ps-3 pe-3 rounded-pill bg-success\">SELESAI</strong>";
                    }else if($fetch['status']==2){
                        echo"<span class=\"text-light pt-1 pb-1 ps-3 pe-3 rounded-pill bg-danger\">DIBATALKAN</strong>";
                    }
                    ?>
                </td>
            </tr>
        </table>
        <?php 
        } else{
        ?>
        <div class="container-fluid p-2 text-center text-light fw-bold fs-4 rounded-2" style="background-color: #4e5180;">
            Tiada Pembelian 
        </div>
        <?php
        }
        ?>
    </div>
	<?php include('../include/footer.php');?>
</body>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
    const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))
</script>
</html>