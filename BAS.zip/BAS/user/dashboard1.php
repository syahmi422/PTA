<?php
include('../include/config.php');
include('../include/session_user.php');

$query=mysqli_query($con,"SELECT * FROM pelajar WHERE id_std='$id'");
$fetch=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>E-TIKET KVKS</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
</head>

<style>
	body{
		font-family: quicksand;
	}
  :root{
    scroll-behavior: smooth;
  }
</style>

<body class="bg-light">
  <?php include('../include/nav_user.php');?>

<!--HOME START-->
  <img src="../image/banner.png" class="img-fluid w-100" id="home">
  <div class="position-absolute top-50 start-0 translate-middle-y fw-bold text-light ps-5">
    <p style="font-size:65px;">TicketEaseKVKS</p>
    <p style="font-size:50px;">Selamat Datang</p>
  </div>
  <div class="container-fluid bg-light p-5">
    <center>
      <table class="table table-border w-50">
          <tr class="table-secondary">
            <th>Bas</th>
            <th>Waktu Tiba</th>
            <th>Purata Tempoh Perjalanan</th>
          </tr>
          <tr>
            <td>Gobi punye bas</td>
            <td>2:00 pm</td>
            <td>1 hingga 2 jam</td>
          </tr>
        </table>
    </center>
  </div>
<!--HOME END-->

<!--CONTACT US START-->

  <div class="container-fluid p-3" style="background-color: #5f7adb;" id="contact">
      <center class="fs-1 fw-bold text-light">HUBUNGI KAMI</center>
      <hr>
      <div class="row justify-content-md-center">
        <?php
        $query=mysqli_query($con,"SELECT * FROM admin WHERE role='1'");
        while($fetch1=mysqli_fetch_array($query)){
        ?>
        <div class="col-3 bg-light m-3 p-3 rounded-3 shadow">
          <center>
            <img src="../image/admin.png" class="rounded-circle m-3 w-25">
          </center>
          <hr>
          <div class="row m-1">
            <div class="col col-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-person-vcard" viewBox="0 0 16 16">
                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5ZM9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8Zm1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5Z"/>
                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2ZM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96c.026-.163.04-.33.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1.006 1.006 0 0 1 1 12V4Z"/>
              </svg>
            </div>
            <div class="col">
              <?=$fetch1['nama'];?>
            </div>
          </div>
          <div class="row m-1">
            <div class="col col-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-telephone" viewBox="0 0 16 16">
                <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
              </svg>
            </div>
            <div class="col">
              <?=$fetch1['notel'];?>
            </div>
          </div>
        </div>
        <?php
        }
        ?>
      </div> 

      <hr>

      <div class="container bg-light rounded-3 p-3 mb-3 shadow">
        <h3>Hantar Kami Mesej</h3>
        <br>
        <form method="POST" action="contact.php">
          <div class="mb-3">
            <labeL class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control" value="<?=$fetch['nama_std']?>" readonly>
          </div>
          <div class="mb-3">
            <labeL class="form-label">Alamat E-mel</label>
            <input type="email" name="emel" class="form-control" value="<?=$fetch['emel']?>" readonly>
          </div>
          <div class="mb-3">
            <labeL class="form-label">Subjek</label>
            <input type="text" name="subjek" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Mesej</label>
            <textarea class="form-control" name="mesej" rows="10" required></textarea>
          </div>
          <button type="submit" name="hantar" class="btn w-100 rounded-pill text-light" style="background-color: #5f7adb;">Hantar</button>
        </form>
      </div>

<!--CONTACT US END-->

  </div>
  <?php 
  include('../include/footer.php');
  ?>

</body>



<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script> -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script>
  const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
  const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))
</script>
</html>