<?php
session_start();
if(!isset($_SESSION['id_admin'])){
    header("Location: login.php");
}else{
    $id=$_SESSION['id_admin'];
}
?>