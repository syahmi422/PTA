<?php
$con=mysqli_connect('localhost','root','','bas')or die();
?>