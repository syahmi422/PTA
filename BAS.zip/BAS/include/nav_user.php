<!-- <ul class="nav justify-content-end sticky-top bg-dark p-4">
    <li class="nav-item">
      <a class="nav-link text-light fw-bold fs-5 me-5" href="dashboard.php #home">Utama</a>
    </li>
    <li class="nav-item">
      <a class="nav-link text-light fw-bold fs-5 me-5" href="dashboard.php #contact">Hubungi Kami</a>
    </li>

    
    <?php
    //if(isset($_SESSION['id'])){
    ?>
    <li class="nav-item">
      <div class="dropdown">
        <button class="btn btn-dark dropdown-toggle text-light fw-bold fs-5 me-5" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          Tiket
        </button>
        <ul class="dropdown-menu p-2">
          <li>
            <a href="tiket.php" class="dropdown-item">Beli Tiket</a>
          </li>
          <li>
            <a href="semak.php" class="dropdown-item">Semak Tiket</a>
          </li>
        </ul>
      </div>
    </li>
    <?php
    //}
    ?>
    <li class="nav-item">
      <div class="dropdown">
        <button class="btn btn-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
              <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
              <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
            </svg>
        </button>
        <?php
        //if(!isset($_SESSION['id'])){
        ?>
        <ul class="dropdown-menu p-2">
          <li>
            <button class="btn btn-success w-100" onclick="window.location='login.php'">Log Masuk</button>
          </li>
        </ul>
        <?php  
        //}else{
        ?>
        <ul class="dropdown-menu p-2">
          <li class="fw-bold">
          <?php //echo $fetch['nama_std'];?>
          </li>
          <li>
            <hr>
          </li>
          <li>
            <button class="btn btn-danger w-100" onclick="window.location='logout.php'">Log Keluar</button>
          </li>
        </ul>
        <?php
        //}
        ?>
      </div>
    </li>
  </ul> -->
<header class="sticky-top">
  <nav style="background-color: #5453a6;" class="navbar navbar-expand-lg navbar-dark sticky-top p-4">
    <a class="navbar-brand fw-bold fs-3" href="../admin/login.php">TicketEaseKVKS</a>
    <button style="background-color: #5453a6;" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item m-2 me-5">
          <a class="nav-link text-white" href="dashboard.php #home">Utama</a>
        </li>
        <li class="nav-item m-2 me-5">
          <a class="nav-link text-white" href="dashboard.php #about">Tentang Kami</a>
        </li>
        <li class="nav-item m-2 me-5">
          <a class="nav-link text-white" href="dashboard.php #contact">Hubungi Kami</a>
        </li>
      
        <?php
        if(!isset($_SESSION['id'])){
        ?>
        <li class="nav-item m-2 me-5">
          <button class="btn btn-outline-light" onclick="window.location='login.php'">Log Masuk</button>
        </li>
        <?php  
        }else{
        ?>
        <li class="nav-item dropdown m-2 me-5">
          <a class="nav-link text-white dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Tiket
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="tiket.php">Beli Tiket</a>
            <a class="dropdown-item" href="semak.php">Semak Pembelian</a>
          </div>
        </li>
        <li class="nav-item m-2 me-5">
          <button class="btn btn-outline-light" onclick="window.location='logout.php'">Log Keluar</button>
        </li>
        <?php
        }
        ?>

      </ul>
    </div>
  </nav>
</header>
