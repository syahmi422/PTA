<?php
if($_SERVE['REQUEST_METHOD']=== 'POST' ){
    if(isset($_POST['hantar'])){
        //required name, tel, email, amount
        $name=$_POST['name'];
    }
}
?>