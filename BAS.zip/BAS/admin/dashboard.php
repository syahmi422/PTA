<?php
include('../include/config.php');
include('../include/session_admin.php');

$query=mysqli_query($con,"SELECT * FROM admin WHERE id_admin='$id'");
$fetch=mysqli_fetch_array($query);

$query1=mysqli_query($con,"SELECT COUNT(bil_tiket) AS jumlah_pembelian, SUM(bil_tiket) AS jumlah_tiket, COUNT(CASE WHEN status='1' THEN 1 END) AS selesai, COUNT(CASE WHEN status='2' THEN 1 END) AS batal FROM tiket");
$fetch1=mysqli_fetch_array($query1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TicketEase KVKS</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.0/dist/sweetalert2.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <link rel="stylesheet" href="node_modules/mdbootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="node_modules/mdbootstrap/css/mdb.min.css">
    <link rel="stylesheet" href="node_modules/mdbootstrap/css/style.css"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.0/dist/sweetalert2.min.css">
</head>

<body class="bg-light pt-4">
    <?php
    include('../include/nav_admin.php');
    ?>
    
    <div class="container-fluid">
        <span class="text-dark fw-bold fs-2">Dashboard</span>
        <br><br>

        <!-- statistik -->
        <div class="row justify-content-center">
            <div class="card m-2 shadow-sm" style="width: 19rem;">
                <div class="card-body">
                    <h5 class="card-title fw-bold">
                        <i class='bx bx-cart p-2 text-white bg-primary rounded-circle'></i>
                        Jumlah Pembelian
                    </h5>
                    <p class="card-text fs-1 fw-bold"><?=$fetch1['jumlah_pembelian']?></p>
                </div>
            </div>
            <div class="card m-2 shadow-sm" style="width: 19rem;">
                <div class="card-body">
                    <h5 class="card-title fw-bold">
                        <i class='bx bx-money p-2 text-white bg-warning rounded-circle'></i>
                        Jumlah Pendapatan
                    </h5>
                    <p class="card-text fs-1 fw-bold">RM <?=$fetch1['jumlah_tiket']*15;?></p>
                </div>
            </div>
            <div class="card m-2 shadow-sm" style="width: 19rem;">
                <div class="card-body">
                    <h5 class="card-title fw-bold">
                        <i class='bx bx-check-circle p-2 text-white bg-success rounded-circle'></i>
                        Pembelian Selesai
                    </h5>
                    <p class="card-text fs-1 fw-bold"><?=$fetch1['selesai']?></p>
                </div>
            </div>
            <div class="card m-2 shadow-sm" style="width: 19rem;">
                <div class="card-body">
                    <h5 class="card-title fw-bold">
                        <i class='bx bx-x-circle p-2 text-white bg-danger rounded-circle'></i>
                        Pembelian Batal
                    </h5>
                    <p class="card-text fs-1 fw-bold"><?=$fetch1['batal']?></p>
                </div>
            </div>
        </div>
        <!-- penutup statistik -->

        <br><br>

        <!-- pending purchases -->
        <p class="fs-3">Senarai Pembeli Yang <span class="text-warning fw-bold">Belum Selesai</span></p>
        <div class="rounded-1 bg-white p-2 shadow-sm table-responsive">
            <table id="dataTablePending" class="table">
                <thead>
                    <tr>
                        <th class="th-md">BIL</th>
                        <th class="th-md">NAMA</th>
                        <th class="th-md">NO. TELEFON</th>
                        <th class="th-md">TINDAKAN</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $bil='1';
                $query=mysqli_query($con,"SELECT * FROM tiket JOIN pelajar ON tiket.id_std = pelajar.id_std WHERE tiket.status='0'");
                while($row=mysqli_fetch_array($query)){
                ?>
                
                    <tr>
                        <th><?=$bil++;?></th>
                        <td><?=$row['nama_std'];?></td>
                        <td><?=$row['no_tel'];?></td>
                        <td>
                            <!-- <a href="success.php?id=<?=$row['id_tkt'];?>" onclick="return confirm('Anda Pasti?')" class="btn btn-success m-1">
                                <i class='bx bx-check-circle text-white fs-5'></i>
                            </a>
                            <a href="cancel.php?id=<?=$row['id_tkt'];?>" onclick="return confirm('Anda Pasti?')" class="btn btn-danger m-1">
                                <i class='bx bx-x-circle text-whit fs-5'></i>
                            </a> -->
                            <button class="btn btn-success m-1 done" data-id="<?=$row['id_tkt']?>">
                                <i class='bx bx-check-circle text-white fs-5'></i>
                            </button>
                            <button class="btn btn-danger m-1 cancel" data-id="<?=$row['id_tkt']?>">
                                <i class='bx bx-x-circle text-whit fs-5'></i>
                            </button>
                        </td>
                    </tr>
                
                <?php
                }
                ?>
                </tbody>
            </table>
        </div>
        <!-- penutup pending purchase -->

        <br><br>

        <!-- cancel purchases -->
        <p class="fs-3">Senarai Pembeli Yang <span class="text-danger fw-bold">Dibatalkan</span></p>
        <div class="rounded-1 bg-white p-2 shadow-sm table-responsive">
            <table id="dataTableCancel" class="table">
                <thead>
                    <tr>
                        <th>BIL</th>
                        <th>NAMA</th>
                        <th>NO. TELEFON</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $bil='1';
                $query=mysqli_query($con,"SELECT * FROM tiket JOIN pelajar ON tiket.id_std = pelajar.id_std WHERE tiket.status='2'");
                while($row=mysqli_fetch_array($query)){
                ?>
                
                    <tr>
                        <th><?=$bil++;?></th>
                        <td><?=$row['nama_std'];?></td>
                        <td><?=$row['no_tel'];?></td>
                    </tr>
                
                <?php
                }
                ?>
                </tbody>
            </table>
        </div>
        <!-- penutup cancel purchase -->
        
        <br><br>
        <?php include('../include/footer.php');?>
    </div>
</body>

<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="node_modules/mdbootstrap/js/jquery.min.js"></script>
<script type="text/javascript" src="node_modules/mdbootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="node_modules/mdbootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="node_modules/mdbootstrap/js/mdb.min.js"></script> -->
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script>new DataTable('#dataTablePending'); new DataTable('#dataTableCancel');</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $('.done').click(function() {
        const id = $(this).data('id');
        Swal.fire({
            title: 'Anda Pasti?',
            text: 'Tiket ini akan diluluskan',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Ya',
            confirmButtonColor: '#5453a6',
            cancelButtonText: 'Tidak',
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'success.php?id='+id;
            }
        });
    });

    $('.cancel').click(function() {
        const id = $(this).data('id');
        Swal.fire({
            title: 'Anda Pasti?',
            text: 'Tiket ini akan dibatalkan',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Ya',
            confirmButtonColor: '#5453a6',
            cancelButtonText: 'Tidak',
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'cancel.php?id='+id;
            }
        });
    });
</script>
<script>
    <?php if (isset($_SESSION['title']) && $_SESSION['title'] != '') { ?>
        Swal.fire({
            confirmButtonColor: '#5453a6',
            title: '<?=$_SESSION['title']; ?>',
            text: '<?=$_SESSION['text']; ?>',
            icon: '<?=$_SESSION['icon']; ?>'
        }).then((result) => {
        if (result.isConfirmed) {
          window.location.href='<?=$_SESSION['location']?>';
        }
      });
    <?php }
    unset($_SESSION['title']); ?>
</script>

</html>