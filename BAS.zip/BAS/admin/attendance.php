<?php
include('../include/config.php');
include('../include/session_admin.php');

// $msg="";
$query = mysqli_query($con, "SELECT * FROM admin WHERE id_admin='$id'");
$fetch = mysqli_fetch_array($query);

if(isset($_POST['validate'])){
    $id=$_POST['id'];

    $check=mysqli_query($con,"SELECT * FROM tiket WHERE id_tkt='$id'");

    if(mysqli_num_rows($check)){
        $_SESSION['title']='Berjaya';
        $_SESSION['icon']='success';
        $_SESSION['text']='Kehadiran ditanda';
        $update=mysqli_query($con,"UPDATE tiket SET attendance='2' WHERE id_tkt='$id'");
    }else{
        // $msg ="
        // <p class='alert alert-danger'>
        // <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-exclamation-triangle-fill' viewBox='0 0 16 16'>
        //   <path d='M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z'/>
        // </svg>
        // ID tidak wujud
        // </p>
        // ";
        $_SESSION['title']='Gagal';
        $_SESSION['icon']='error';
        $_SESSION['text']='ID tidak wujud';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TicketEase KVKS</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.0/dist/sweetalert2.min.css">
</head>

<body class="bg-light pt-4">
    <?php
    include('../include/nav_admin.php');
    ?>

    <div class="container-fluid">
        <span class="text-dark fw-bold fs-2">Pengesahan Tiket</span>
        <br><br>

        <div class="col-sm col-lg-4 bg-white p-3 rounded-2 shadow-sm">
            <form method="POST">
                <span class="">Masukkan ID tiket</span>
                <div class="input-group mb-3 mt-2">
                    <input type="text" class="form-control" placeholder="ID Tiket" aria-describedby="button-addon2" name="id" required>
                    <button class="btn btn-outline-primary" type="submit" id="button-addon2" name="validate">
                        <i class='bx bxs-coupon fs-5'></i>
                    </button>
                </div>
            </form>
            <hr>
            
            <!-- <button class="btn btn-primary w-100 mt-2">
                <i class='bx bx-qr-scan'></i>
                Imbas QR Code
            </button> -->
        </div>
        
         <div class="rounded-1 bg-white p-2 shadow-sm table-responsive mt-4">
            <table id="dataTableAttendance" class="table">
                <thead>
                    <tr>
                        <th>BIL</th>
                        <th>ID TIKET</th>
                        <th>NAMA</th>
                        <th>STATUS</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $bil = '1';
                $query = mysqli_query($con, "SELECT * FROM tiket JOIN pelajar ON tiket.id_std = pelajar.id_std WHERE tiket.status='1'");
                while ($row = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?=$bil++?></td>
                        <td><?=$row['id_tkt']?></td>
                        <td><?=$row['nama_std']?></td>
                        <td>
                        <?php
                            if($row['attendance']=='1'){
                        ?>
                            <span class="alert alert-danger p-1">TIDAK HADIR</span>
                        <?php   
                            }else if($row['attendance']=='2'){
                        ?>
                            <span class="alert alert-success p-1">HADIR</span>
                        <?php
                            }
                        ?>
                        </td>
                    </tr>
                <?php
                }
                ?>
                </tbody>
            </table>
        </div>

        <br><br>
        <?php include('../include/footer.php'); ?>
    </div>
</body>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script>new DataTable('#dataTableAttendance');</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    <?php if (isset($_SESSION['title']) && $_SESSION['title'] != '') { ?>
        Swal.fire({
            confirmButtonColor: '#5453a6',
            title: '<?php echo $_SESSION['title']; ?>',
            text: '<?php echo $_SESSION['text']; ?>',
            icon: '<?php echo $_SESSION['icon']; ?>'
        });
    <?php }
    unset($_SESSION['title']); ?>
</script>

</html>
